

// scripts.js - Add interactivity and client-side validation

// Simple form validation for add debt form
const debtForm = document.querySelector("#debtForm");
if (debtForm) {
    debtForm.addEventListener("submit", function (event) {
        const amount = document.querySelector("input[name='amount']").value;
        const interestRate = document.querySelector("input[name='interest_rate']").value;
        const dueDate = document.querySelector("input[name='due_date']").value;

        // Ensure valid numbers for amount and interest rate
        if (amount <= 0 || interestRate < 0) {
            alert("Please enter valid numbers for amount and interest rate.");
            event.preventDefault(); // Prevent form submission
        }

        // Ensure a due date is selected
        const now = new Date();
        const selectedDate = new Date(dueDate);
        if (selectedDate < now) {
            alert("Please select a due date in the future.");
            event.preventDefault();
        }
    });
}

// Budget tracking - Update remaining amount dynamically
document.addEventListener("DOMContentLoaded", function () {
    const budgetRows = document.querySelectorAll(".budget-row");
    budgetRows.forEach(function (row) {
        const allocatedAmount = parseFloat(row.querySelector(".allocated-amount").textContent);
        const spentAmount = parseFloat(row.querySelector(".spent-amount").textContent);
        const remainingElement = row.querySelector(".remaining-amount");

        // Update remaining amount
        if (remainingElement) {
            remainingElement.textContent = (allocatedAmount - spentAmount).toFixed(2);

            // Highlight overspending
            if (allocatedAmount - spentAmount < 0) {
                remainingElement.style.color = "red";
            } else {
                remainingElement.style.color = "green";
            }
        }
    });
});