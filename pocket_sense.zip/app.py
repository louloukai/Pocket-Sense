from flask import Flask, render_template, request, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
import os
import datetime

app = Flask(__name__)

# ----------------------- Configuration ----------------------- #

# Define the database path in the 'db' folder
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'db/app.db')

# Ensure the 'db' directory exists
if not os.path.exists(os.path.join(BASE_DIR, 'db')):
    os.makedirs(os.path.join(BASE_DIR, 'db'))

# SQLite Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_PATH}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
db = SQLAlchemy(app)

# ------------------------ Database Models --------------------- #

class Debt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    debtor = db.Column(db.String(100), nullable=False)
    creditor = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    interest_rate = db.Column(db.Float, nullable=False)
    due_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), default="Active")


class Budget(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(100), nullable=False)
    allocated_amount = db.Column(db.Float, nullable=False)
    spent_amount = db.Column(db.Float, default=0)

# ------------------------ Initialize Database --------------------- #

@app.before_request
def setup_database():
    """
    This function ensures the database and tables are created before the first request.
    """
    db.create_all()

# -------------------------- Routes (Debt Tracker) ----------------------- #

@app.route('/')
def index():
    # Landing page for navigation
    return render_template('index.html')


@app.route('/debt-tracker', methods=['GET', 'POST'])
def debt_tracker():
    if request.method == 'POST':
        # Add new debt
        debtor = request.form['debtor']
        creditor = request.form['creditor']
        amount = float(request.form['amount'])
        interest_rate = float(request.form['interest_rate'])
        due_date = datetime.datetime.strptime(request.form['due_date'], '%Y-%m-%d').date()

        new_debt = Debt(debtor=debtor, creditor=creditor, amount=amount, interest_rate=interest_rate, due_date=due_date)
        db.session.add(new_debt)
        db.session.commit()

        return redirect('/debt-tracker')

    # Get all debts
    debts = Debt.query.all()
    return render_template('debt_tracker.html', debts=debts)


@app.route('/debt-tracker/delete/<int:id>')
def delete_debt(id):
    debt = Debt.query.get(id)
    if debt:
        db.session.delete(debt)
        db.session.commit()
    return redirect('/debt-tracker')

# -------------------------- Routes (Budget Tracker) ---------------------- #

@app.route('/budget-tracker', methods=['GET', 'POST'])
def budget_tracker():
    if request.method == 'POST':
        # Add new budget
        category = request.form['category']
        allocated_amount = float(request.form['allocated_amount'])

        new_budget = Budget(category=category, allocated_amount=allocated_amount)
        db.session.add(new_budget)
        db.session.commit()

        return redirect('/budget-tracker')

    # Get all budgets
    budgets = Budget.query.all()
    return render_template('budget_tracker.html', budgets=budgets)


@app.route('/budget-tracker/add-expense/<int:id>', methods=['POST'])
def add_expense(id):
    # Add an expense to a specific budget
    amount = float(request.form['amount'])
    budget = Budget.query.get(id)
    if budget:
        budget.spent_amount += amount
        db.session.commit()
    return redirect('/budget-tracker')

# -------------------------- API Endpoints ---------------------- #

@app.route('/api/debts', methods=['GET'])
def get_debts():
    """
    API Endpoint to retrieve all debts in JSON format.
    """
    debts = Debt.query.all()
    return jsonify([
        {
            'debtor': debt.debtor,
            'creditor': debt.creditor,
            'amount': debt.amount,
            'interest_rate': debt.interest_rate,
            'due_date': debt.due_date.strftime('%Y-%m-%d'),
            'status': debt.status
        } for debt in debts
    ])


@app.route('/api/budgets', methods=['GET'])
def get_budgets():
    """
    API Endpoint to retrieve all budgets in JSON format.
    """
    budgets = Budget.query.all()
    return jsonify([
        {
            'category': budget.category,
            'allocated_amount': budget.allocated_amount,
            'spent_amount': budget.spent_amount,
            'remaining': budget.allocated_amount - budget.spent_amount
        } for budget in budgets
    ])

# ----------------------- Run Application ---------------------- #

if __name__ == '__main__':
    app.run(debug=True)